# This is the release version of Memorier, you can use it if you cannot compile the dynamic link library for Qt MySQL.

## Only Windows and Linux version is available, **these two release do not need Qt envirment!**

**We recommand you to use the Linux version since there are some UI/display bugs with Windows version!**  
For Linux version, please double click the **Memorier-0.2-linux** to run the program (already tested!)  
For Windows version, please unzip and double click the **Memorier.exe** to run the program  
If there is any problem running the program(ie database cannot connect), please do contact us!
