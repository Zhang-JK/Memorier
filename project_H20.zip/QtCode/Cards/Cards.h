#ifndef CARDS_H
#define CARDS_H

#include "Card.h"
#include "Plain.h"
#include "Word.h"
#include "Choices.h"
#include "Text.h"

#endif // CARDS_H
