#ifndef TOOLS_H
#define TOOLS_H

#include <QString>

QString getRandomString(int length);

bool InsertLog(int id, QString recording);

#endif